class UserProfile:
    def __init__(self, name: str = None):
        self.name = name